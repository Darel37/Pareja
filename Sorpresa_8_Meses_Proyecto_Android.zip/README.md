# Sorpresa 8 meses — Android

Proyecto Android nativo que muestra la experiencia romántica en un WebView local. No necesita permisos ni conexión a internet.

## Generar el APK
1. Instala Android Studio (versión compatible con Android Gradle Plugin 8.7.3) y Android SDK Platform 35.
2. Abre esta carpeta como proyecto en Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio mostrará el enlace al APK generado, normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

Para distribuirla fuera de pruebas, crea un APK firmado desde **Build > Generate Signed Bundle / APK**.
